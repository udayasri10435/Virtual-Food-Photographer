/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Camera, 
  Utensils, 
  Settings, 
  Sparkles, 
  Image as ImageIcon, 
  Loader2, 
  Download, 
  RefreshCw,
  ChevronRight,
  AlertCircle,
  Key
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { parseMenu, generateFoodImage, Dish, ImageStyle, ImageSize } from './lib/gemini';

declare global {
  interface Window {
    aistudio: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

export default function App() {
  const [menuText, setMenuText] = useState('');
  const [style, setStyle] = useState<ImageStyle>('modern');
  const [size, setSize] = useState<ImageSize>('1K');
  const [dishes, setDishes] = useState<(Dish & { imageUrl?: string; loading?: boolean; error?: string })[]>([]);
  const [isParsing, setIsParsing] = useState(false);
  const [hasApiKey, setHasApiKey] = useState(false);
  const [isCheckingKey, setIsCheckingKey] = useState(true);

  useEffect(() => {
    checkApiKey();
  }, []);

  const checkApiKey = async () => {
    if (window.aistudio) {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      setHasApiKey(hasKey);
    }
    setIsCheckingKey(false);
  };

  const handleSelectKey = async () => {
    if (window.aistudio) {
      await window.aistudio.openSelectKey();
      setHasApiKey(true);
    }
  };

  const handleGenerate = async () => {
    if (!menuText.trim()) return;
    
    setIsParsing(true);
    try {
      const parsedDishes = await parseMenu(menuText);
      setDishes(parsedDishes.map(d => ({ ...d, loading: true })));
      setIsParsing(false);

      // Generate images sequentially or in small batches to avoid rate limits
      for (let i = 0; i < parsedDishes.length; i++) {
        const dish = parsedDishes[i];
        try {
          const imageUrl = await generateFoodImage(dish, style, size);
          setDishes(prev => prev.map((d, idx) => 
            idx === i ? { ...d, imageUrl: imageUrl || undefined, loading: false } : d
          ));
        } catch (error: any) {
          if (error.message === "API_KEY_EXPIRED") {
            setHasApiKey(false);
            setDishes(prev => prev.map((d, idx) => 
              idx === i ? { ...d, loading: false, error: "API Key issue. Please re-select." } : d
            ));
            break;
          }
          setDishes(prev => prev.map((d, idx) => 
            idx === i ? { ...d, loading: false, error: "Failed to generate image." } : d
          ));
        }
      }
    } catch (error) {
      console.error(error);
      setIsParsing(false);
    }
  };

  const regenerateImage = async (index: number) => {
    const dish = dishes[index];
    setDishes(prev => prev.map((d, i) => i === index ? { ...d, loading: true, error: undefined } : d));
    
    try {
      const imageUrl = await generateFoodImage(dish, style, size);
      setDishes(prev => prev.map((d, i) => 
        i === index ? { ...d, imageUrl: imageUrl || undefined, loading: false } : d
      ));
    } catch (error: any) {
      if (error.message === "API_KEY_EXPIRED") {
        setHasApiKey(false);
      }
      setDishes(prev => prev.map((d, i) => 
        i === index ? { ...d, loading: false, error: "Failed to generate image." } : d
      ));
    }
  };

  if (isCheckingKey) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-orange-500 animate-spin" />
      </div>
    );
  }

  if (!hasApiKey) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] text-white flex flex-col items-center justify-center p-6 text-center">
        <div className="w-20 h-20 bg-orange-500/10 rounded-full flex items-center justify-center mb-6">
          <Key className="w-10 h-10 text-orange-500" />
        </div>
        <h1 className="text-3xl font-bold mb-4">API Key Required</h1>
        <p className="text-gray-400 max-w-md mb-8">
          To generate high-quality food photography using Gemini 3 Pro, you need to select a paid API key.
        </p>
        <button 
          onClick={handleSelectKey}
          className="px-8 py-3 bg-orange-500 hover:bg-orange-600 text-white font-semibold rounded-full transition-all flex items-center gap-2"
        >
          Select API Key
        </button>
        <a 
          href="https://ai.google.dev/gemini-api/docs/billing" 
          target="_blank" 
          rel="noopener noreferrer"
          className="mt-4 text-sm text-gray-500 hover:text-gray-300 underline"
        >
          Learn about Gemini API billing
        </a>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-orange-500/30">
      {/* Header */}
      <header className="border-b border-white/10 px-6 py-4 flex items-center justify-between sticky top-0 bg-[#0a0a0a]/80 backdrop-blur-md z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/20">
            <Camera className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">Virtual Food Photographer</h1>
            <p className="text-xs text-gray-500 font-medium uppercase tracking-widest">AI Studio Edition</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={handleSelectKey}
            className="text-xs text-gray-400 hover:text-white flex items-center gap-1 transition-colors"
          >
            <Key className="w-3 h-3" /> Change Key
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-[400px_1fr] gap-0 min-h-[calc(100-65px)]">
        {/* Sidebar Controls */}
        <aside className="border-r border-white/10 p-6 space-y-8 overflow-y-auto max-h-[calc(100vh-65px)]">
          <section className="space-y-4">
            <div className="flex items-center gap-2 text-orange-500">
              <Utensils className="w-4 h-4" />
              <h2 className="text-sm font-semibold uppercase tracking-wider">Your Menu</h2>
            </div>
            <textarea 
              value={menuText}
              onChange={(e) => setMenuText(e.target.value)}
              placeholder="Paste your menu items here...&#10;e.g.&#10;1. Truffle Mushroom Risotto with parmesan shavings&#10;2. Grilled Salmon with asparagus and lemon butter"
              className="w-full h-64 bg-white/5 border border-white/10 rounded-xl p-4 text-sm focus:outline-none focus:border-orange-500/50 transition-colors resize-none placeholder:text-gray-600"
            />
          </section>

          <section className="space-y-6">
            <div className="flex items-center gap-2 text-orange-500">
              <Settings className="w-4 h-4" />
              <h2 className="text-sm font-semibold uppercase tracking-wider">Photography Style</h2>
            </div>
            
            <div className="grid grid-cols-1 gap-3">
              {[
                { id: 'modern', name: 'Bright & Modern', desc: 'Clean, minimalist, white marble' },
                { id: 'rustic', name: 'Rustic & Dark', desc: 'Moody, wood textures, cinematic' },
                { id: 'social', name: 'Social Media', desc: 'Top-down flat lay, trendy props' }
              ].map((s) => (
                <button
                  key={s.id}
                  onClick={() => setStyle(s.id as ImageStyle)}
                  className={`p-4 rounded-xl border text-left transition-all ${
                    style === s.id 
                      ? 'bg-orange-500/10 border-orange-500 text-white' 
                      : 'bg-white/5 border-white/10 text-gray-400 hover:border-white/20'
                  }`}
                >
                  <div className="font-semibold text-sm mb-1">{s.name}</div>
                  <div className="text-xs opacity-60">{s.desc}</div>
                </button>
              ))}
            </div>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-2 text-orange-500">
              <ImageIcon className="w-4 h-4" />
              <h2 className="text-sm font-semibold uppercase tracking-wider">Image Resolution</h2>
            </div>
            <div className="flex gap-2">
              {['1K', '2K', '4K'].map((s) => (
                <button
                  key={s}
                  onClick={() => setSize(s as ImageSize)}
                  className={`flex-1 py-2 rounded-lg border text-xs font-bold transition-all ${
                    size === s 
                      ? 'bg-white text-black border-white' 
                      : 'bg-white/5 border-white/10 text-gray-400 hover:border-white/20'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </section>

          <button 
            onClick={handleGenerate}
            disabled={!menuText.trim() || isParsing}
            className="w-full py-4 bg-orange-500 hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-orange-500/20"
          >
            {isParsing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Parsing Menu...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                Generate Photography
              </>
            )}
          </button>
        </aside>

        {/* Main Content Area */}
        <section className="p-8 overflow-y-auto max-h-[calc(100vh-65px)] bg-[#0f0f0f]">
          {dishes.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-6 opacity-40">
              <div className="w-24 h-24 border-2 border-dashed border-white/20 rounded-full flex items-center justify-center">
                <ImageIcon className="w-10 h-10" />
              </div>
              <div className="max-w-xs">
                <h3 className="text-lg font-semibold mb-2">No Photos Generated</h3>
                <p className="text-sm">Upload your menu and select a style to start generating professional photography.</p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <AnimatePresence mode="popLayout">
                {dishes.map((dish, index) => (
                  <motion.div 
                    key={index}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="group bg-white/5 rounded-2xl overflow-hidden border border-white/10 hover:border-white/20 transition-all"
                  >
                    <div className="aspect-square relative bg-black flex items-center justify-center overflow-hidden">
                      {dish.loading ? (
                        <div className="flex flex-col items-center gap-3">
                          <Loader2 className="w-8 h-8 text-orange-500 animate-spin" />
                          <span className="text-xs font-medium text-gray-500 uppercase tracking-widest">Developing...</span>
                        </div>
                      ) : dish.error ? (
                        <div className="flex flex-col items-center gap-3 p-6 text-center">
                          <AlertCircle className="w-8 h-8 text-red-500" />
                          <span className="text-xs font-medium text-red-500/80 uppercase tracking-widest">{dish.error}</span>
                          <button 
                            onClick={() => regenerateImage(index)}
                            className="mt-2 text-xs bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full transition-colors"
                          >
                            Try Again
                          </button>
                        </div>
                      ) : dish.imageUrl ? (
                        <>
                          <img 
                            src={dish.imageUrl} 
                            alt={dish.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                          />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                            <button 
                              onClick={() => {
                                const link = document.createElement('a');
                                link.href = dish.imageUrl!;
                                link.download = `${dish.name.replace(/\s+/g, '-').toLowerCase()}.png`;
                                link.click();
                              }}
                              className="p-3 bg-white text-black rounded-full hover:scale-110 transition-transform"
                            >
                              <Download className="w-5 h-5" />
                            </button>
                            <button 
                              onClick={() => regenerateImage(index)}
                              className="p-3 bg-white text-black rounded-full hover:scale-110 transition-transform"
                            >
                              <RefreshCw className="w-5 h-5" />
                            </button>
                          </div>
                        </>
                      ) : null}
                    </div>
                    <div className="p-5 space-y-2">
                      <div className="flex items-center justify-between">
                        <h3 className="font-bold text-lg leading-tight">{dish.name}</h3>
                        <span className="text-[10px] font-bold px-2 py-1 bg-white/10 rounded uppercase tracking-wider text-gray-400">
                          {size}
                        </span>
                      </div>
                      <p className="text-sm text-gray-400 line-clamp-2 leading-relaxed italic">
                        "{dish.description}"
                      </p>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </section>
      </main>

      {/* Footer Branding */}
      <footer className="fixed bottom-6 right-6 pointer-events-none">
        <div className="bg-black/80 backdrop-blur-md border border-white/10 px-4 py-2 rounded-full flex items-center gap-2 shadow-2xl">
          <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse" />
          <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400">Powered by Gemini 3 Pro</span>
        </div>
      </footer>
    </div>
  );
}
