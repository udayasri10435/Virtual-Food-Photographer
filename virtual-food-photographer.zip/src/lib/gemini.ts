import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

export type ImageStyle = 'rustic' | 'modern' | 'social';
export type ImageSize = '1K' | '2K' | '4K';

export interface Dish {
  name: string;
  description: string;
}

export const parseMenu = async (menuText: string): Promise<Dish[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-latest",
    contents: [{ parts: [{ text: `Parse the following restaurant menu text into a JSON array of objects. Each object should have "name" (the dish name) and "description" (a brief visual description for a photographer). 
    
    Menu Text:
    ${menuText}
    
    Return ONLY the JSON array.` }] }],
    config: {
      responseMimeType: "application/json",
    }
  });

  try {
    return JSON.parse(response.text || '[]');
  } catch (e) {
    console.error("Failed to parse menu JSON", e);
    return [];
  }
};

export const generateFoodImage = async (dish: Dish, style: ImageStyle, size: ImageSize): Promise<string | null> => {
  // Create a fresh instance to ensure we use the latest API key from the environment
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || process.env.GEMINI_API_KEY || '' });

  let stylePrompt = "";
  switch (style) {
    case 'rustic':
      stylePrompt = "Rustic and dark aesthetic, moody lighting, dark wood background, high contrast, textured surfaces, artisanal feel, professional food photography, 8k resolution, cinematic.";
      break;
    case 'modern':
      stylePrompt = "Bright and modern aesthetic, airy lighting, clean white marble background, minimalist styling, vibrant natural colors, professional food photography, 8k resolution, high-end restaurant style.";
      break;
    case 'social':
      stylePrompt = "Social media flat lay style, top-down perspective, trendy props, overhead shot, Instagram aesthetic, bright and colorful, professional food photography, 8k resolution.";
      break;
  }

  const prompt = `A professional, high-end food photograph of ${dish.name}. ${dish.description}. ${stylePrompt}`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
          imageSize: size
        }
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
  } catch (error) {
    console.error("Error generating image:", error);
    if (error instanceof Error && error.message.includes("Requested entity was not found")) {
        throw new Error("API_KEY_EXPIRED");
    }
  }
  return null;
};
